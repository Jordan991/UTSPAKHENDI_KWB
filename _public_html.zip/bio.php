<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bio</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .bio-img {
            width: 350px; 
            height: auto;
            border: 100px solid #333; 
            border-radius: 50px; 
            padding: 5px; 
            margin-bottom: 10px; 
            transition: transform 0.3s, border-color 0.3s; 
        }
        .bio-img:hover {
            transform: scale(1.05); 
            border-color: #5b4237; 
        }
        .social-media {
            display: flex;
            gap: 15px; 
            margin-top: 20px; 
        }
        .social-media img {
            width: 30px; 
            height: 30px; 
            border: 2px solid #333; 
            border-radius: 50%; 
            padding: 5px; 
            transition: transform 0.3s, border-color 0.3s; 
        }
        .social-media img:hover {
            transform: scale(1.1); 
            border-color: #5b4237; 
        }
    </style>
</head>
<body>
    <?php include './partials/navbar.php'; ?>

    <?php
  $servername = "localhost";
  $username = "u834314004_root"; 
  $password = "Ortubahagia12345."; 
  $dbname = "u834314004_utskwh";

    // Membuat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Memeriksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data dari tabel bio
    $sql = "SELECT name, description, photo, instagram, facebook, twitter, linkedin FROM bio"; 
    $result = $conn->query($sql);

    // Ambil data dari query
    $bioData = $result->fetch_assoc();
    ?>

    <section id="bio" class="section">
        <div class="container">
            <h1><?php echo $bioData['name']; ?></h1>
            <img src="<?php echo $bioData['photo']; ?>" alt="Foto <?php echo $bioData['name']; ?>" class="bio-img">
            <p><?php echo $bioData['description']; ?></p>
            
            <div class="social-media">
                <a href="<?php echo $bioData['instagram']; ?>" target="_blank"><img src="images/instagram.png" alt="Instagram"></a>
                <a href="<?php echo $bioData['facebook']; ?>" target="_blank"><img src="images/facebook.png" alt="Facebook"></a>
                <a href="<?php echo $bioData['twitter']; ?>" target="_blank"><img src="images/twitter.png" alt="Twitter"></a>
                <a href="<?php echo $bioData['linkedin']; ?>" target="_blank"><img src="images/linkedin.png" alt="LinkedIn"></a>
            </div>
        </div>
    </section>

    <?php
    // Menutup koneksi
    $conn->close();
    ?>
</body>
</html>
