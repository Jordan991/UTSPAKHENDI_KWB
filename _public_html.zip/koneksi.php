<?php
$servername = "localhost";
$username = "u834314004_root"; 
$password = "Ortubahagia12345."; 
$dbname = "u834314004_utskwh";
$port = "3306";
// Aktifkan mode exception
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Buat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
    // Cek koneksi
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
 
} catch (mysqli_sql_exception $error) {
    // Ketika terjadi kesalahan koneksi
    echo "Koneksi gagal: " . $error->getMessage();
}
?>