<nav>
    <ul class="navbar">
        <li><a href="bio.php">Bio</a></li>
        <li><a href="mycollage.php">My Collage</a></li>
        <li><a href="mydream.php">My Dream</a></li>
        <li><a href="form.php">Form</a></li>
        <li><a href="index.php">Portfolio</a></li>
    </ul>
</nav>
