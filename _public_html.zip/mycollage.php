<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Collage</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .campus-logo {
            width: 150px; 
            height: auto;
            border: 4px solid #333; 
            border-radius: 10px; 
            padding: 5px; 
            margin-bottom: 20px; 
            display: block;
            margin-left: auto;
            margin-right: auto; 
            transition: transform 0.3s, border-color 0.3s; 
        }
        .campus-logo:hover {
            transform: scale(1.05); 
            border-color: #5b4237; 
        }
    </style>
</head>
<body>
    <?php include './partials/navbar.php'; ?>

    <?php
    // Koneksi ke database
    $servername = "localhost";
    $username = "u834314004_root"; 
    $password = "Ortubahagia12345."; 
    $dbname = "u834314004_utskwh";

    // Membuat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Memeriksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data dari tabel collages
    $sql = "SELECT title, description, image FROM collages"; // Pastikan tabel ini ada di database
    $result = $conn->query($sql);

    // Ambil data dari query
    $collageData = $result->fetch_assoc();
    ?>

    <section id="collage" class="section">
        <div class="container">
            <h1><?php echo $collageData['title']; ?></h1>
            <img src="<?php echo $collageData['image']; ?>" alt="Logo Universitas" class="campus-logo">
            <p><?php echo $collageData['description']; ?></p>
        </div>
    </section>

    <?php
    // Menutup koneksi
    $conn->close();
    ?>
</body>
</html>
