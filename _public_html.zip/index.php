<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include './partials/navbar.php'; ?>
    
    <?php
    // Koneksi ke database
    $servername = "localhost";
    $username = "u834314004_root"; 
    $password = "Ortubahagia12345."; 
    $dbname = "u834314004_utskwh";

    // Membuat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Memeriksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data dari tabel projects
    $sql = "SELECT title, description, link FROM projects"; // Pastikan tabel ini ada di database
    $result = $conn->query($sql);
    ?>

    <section class="section">
        <div class="container">
            <h1>Portfolio Jordan</h1>
            <p>Halo, saya Jordan, seorang web developer yang sedang menempuh pendidikan di Universitas Pembangunan Jaya di bidang Informatika. Di sini, Anda akan menemukan portofolio saya yang berisi berbagai proyek yang telah saya kerjakan selama studi dan pengalaman saya di dunia pengembangan web.
            Saya memiliki keahlian dalam HTML, CSS, dan JavaScript, serta pengalaman dengan beberapa framework modern. Melalui portofolio ini, saya ingin menunjukkan kemampuan saya dalam menciptakan situs web yang menarik, fungsional, dan responsif.
            Setiap proyek yang saya tampilkan di sini mencerminkan dedikasi saya terhadap kualitas dan inovasi. Saya selalu terbuka untuk belajar dan menerima tantangan baru, dan saya percaya bahwa setiap pengalaman adalah kesempatan untuk berkembang.
            Terima kasih telah mengunjungi portofolio saya. Saya berharap Anda menikmati melihat karya-karya saya dan tidak ragu untuk menghubungi saya jika Anda memiliki pertanyaan atau ingin berkolaborasi!</p>

            <h2>Proyek Saya</h2>
            <ul>
                <?php
                // Memeriksa apakah ada hasil
                if ($result->num_rows > 0) {
                    // Menampilkan data setiap baris
                    while ($row = $result->fetch_assoc()) {
                        echo "<li><strong>" . $row["title"] . ":</strong> " . $row["description"] . " <a href='mydream.php'" . $row["link"] . "'>Impian</a></li>";
                    }
                } else {
                    echo "<li>Tidak ada proyek yang ditemukan.</li>";
                }

                // Menutup koneksi
                $conn->close();
                ?>
            </ul>
        </div>
    </section>
</body>
</html>
