<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .dream-image {
            width: 300px; 
            height: auto;
            border: 4px solid #333; 
            border-radius: 10px; 
            padding: 5px; 
            margin-bottom: 20px; 
            display: block;
            margin-left: auto;
            margin-right: auto; 
            transition: transform 0.3s, border-color 0.3s; 
        }
        .dream-image:hover {
            transform: scale(1.05); 
            border-color: #5b4237; 
        }
    </style>
</head>
<body>
    <?php include './partials/navbar.php'; ?>

    <?php
   $servername = "localhost";
   $username = "u834314004_root"; 
   $password = "Ortubahagia12345."; 
   $dbname = "u834314004_utskwh";

    // Membuat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Memeriksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data dari tabel dreams
    $sql = "SELECT title, content, image FROM dreams"; // Pastikan tabel ini ada di database
    $result = $conn->query($sql);

    // Ambil data dari query
    $dreamData = $result->fetch_assoc();
    ?>

    <section id="mydream" class="section">
        <div class="container">
            <h1><?php echo $dreamData['title']; ?></h1>
            <img src="<?php echo $dreamData['image']; ?>" alt="Gambar Impian" class="dream-image">
            <p><?php echo $dreamData['content']; ?></p>
        </div>
    </section>

    <?php
    // Menutup koneksi
    $conn->close();
    ?>
</body>
</html>
